from distutils.core import setup

setup(
    name='python_app_practice1',
    version='1.0.0',
    packages=[''],
    url='https://github.com/Sanban-curry',
    license='Free',
    author='Yusuke.S',
    author_email='sanban.curry@gmail.com',
    description='My first practice python app ver1.0.0'
)
